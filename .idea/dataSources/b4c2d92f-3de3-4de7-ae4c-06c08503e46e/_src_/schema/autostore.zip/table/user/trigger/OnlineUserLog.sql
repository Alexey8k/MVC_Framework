CREATE TRIGGER OnlineUserLog
AFTER UPDATE ON user
FOR EACH ROW
  BEGIN
    IF NOT OLD.online <=> NEW.online THEN
      IF NEW.online = 1 THEN
        INSERT INTO `LogOnlineUser` SET `userId` = NEW.id;
      ELSE
        UPDATE `LogOnlineUser`
          SET `dateOut` = NOW()
          WHERE `userId` = NEW.id AND `dateOut` IS NULL;
      END IF;
    END IF;
  END;
