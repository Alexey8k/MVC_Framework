CREATE PROCEDURE SaveProduct(IN `_id`       INT, IN `_name` VARCHAR(100), IN `_description` VARCHAR(500),
                             IN `_category` VARCHAR(25), IN `_price` DOUBLE(16, 2), IN `_image` LONGBLOB)
  BEGIN
    DECLARE _categoryId VARCHAR(25);
    SELECT `id` INTO _categoryId FROM `Category` WHERE `name`=_category;
    IF IsExistsProduct(_id)
    THEN
      UPDATE `Product`
      SET `name`=_name,
        `description`=_description,
        `categoryId`=_categoryId,
        `price`=_price,
        `imageData`=IF(_image<>'', TO_BASE64(_image), `imageData`)
      WHERE `id`=_id;
    ELSE
      INSERT INTO `Product`(`name`,`description`,`categoryId`,`price`,`imageData`)
      VALUES (_name,_description,_categoryId,_price,TO_BASE64(_image));
    END IF;
  END;
