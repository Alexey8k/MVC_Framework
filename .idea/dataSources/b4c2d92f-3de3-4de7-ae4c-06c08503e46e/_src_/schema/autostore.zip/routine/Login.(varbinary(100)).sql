CREATE PROCEDURE Login(IN hash VARBINARY(100))
  BEGIN
    DECLARE `result` TINYINT DEFAULT 2;
    SELECT CASE `online` WHEN 1 THEN 1 ELSE 0 END INTO `result` FROM `User` AS u WHERE u.`hash`=`hash`;
    IF result = 0
    THEN UPDATE `User` AS u SET `online` = 1 WHERE u.`hash` = `hash`;
    END IF;
    SELECT `result` AS rresalt;
  END;
