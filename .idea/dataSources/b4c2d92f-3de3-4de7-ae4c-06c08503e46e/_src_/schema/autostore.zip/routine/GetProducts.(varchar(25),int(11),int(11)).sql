CREATE PROCEDURE GetProducts(IN `_category` VARCHAR(25), IN `_page` INT, IN `_count` INT)
  BEGIN
    DECLARE _offset INT DEFAULT (_page-1)*_count;
    SELECT p.`id`,p.`name`,p.`price`,p.`description`
    FROM `Product` p
      JOIN (
             SELECT *
             FROM `Product`
             WHERE categoryId IN (SELECT c.id FROM Category c WHERE c.name=_category OR _category='')
             ORDER BY `id`
             LIMIT _offset, _count) plo
        ON p.`id`=plo.`id`;
  END;
