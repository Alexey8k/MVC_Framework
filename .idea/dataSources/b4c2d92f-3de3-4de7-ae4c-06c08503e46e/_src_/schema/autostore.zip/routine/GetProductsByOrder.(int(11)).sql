CREATE PROCEDURE GetProductsByOrder(IN `_id` INT)
  BEGIN
    SELECT p.id,p.name,p.description,c.name category,p.price,op.quantity
    FROM `OrderProduct` op
      JOIN `Product` p ON op.productId = p.id
      JOIN `Category` c ON p.categoryId = c.id
    WHERE op.orderId=_id;
  END;
