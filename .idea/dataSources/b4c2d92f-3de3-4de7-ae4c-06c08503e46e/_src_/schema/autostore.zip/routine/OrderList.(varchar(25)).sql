CREATE PROCEDURE OrderList(IN `_status` VARCHAR(25))
  BEGIN
    SELECT o.id,s.name status,o.name userName,o.date,TotalPriseByOrder(o.id) totalPrise
    FROM `Order` o
      JOIN `Status` s ON o.statusId = s.id
    WHERE `statusId` IN (SELECT `id` FROM `Status` WHERE `name`=_status)
    ORDER BY `id`;
  END;
