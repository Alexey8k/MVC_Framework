CREATE PROCEDURE Logout(IN `_id` INT)
  BEGIN
    UPDATE `User` SET `online` = 0 WHERE `id` = _id AND `online` = 1;
  END;
