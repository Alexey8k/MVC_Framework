CREATE PROCEDURE GetQuantityByCategory(IN `_category` VARCHAR(25))
  BEGIN
    SELECT `GetCountByCategory`(_category) AS 'quantity';
  END;
