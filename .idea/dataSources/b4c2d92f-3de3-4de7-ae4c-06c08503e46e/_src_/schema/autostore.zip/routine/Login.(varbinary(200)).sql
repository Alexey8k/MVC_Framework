CREATE PROCEDURE Login(IN `_hash` VARBINARY(200))
  BEGIN
    DECLARE _result TINYINT DEFAULT 2;
    DECLARE _id INT DEFAULT NULL;
    DECLARE _login, _role VARCHAR(25) DEFAULT NULL;

    SELECT 0 # CASE `online` WHEN 1 THEN 1 ELSE 0 END
      ,IF(_result, NULL, u.`id`)
      ,IF(_result, NULL, u.`login`)
      ,IF(_result, NULL, r.`name`)
    INTO _result, _id, _login, _role
    FROM `User` u
      JOIN `Role` r ON u.roleId = r.id
    WHERE `hash`=_hash;

#     IF _result = 0 THEN
#       UPDATE `User` SET `online` = 1 WHERE `hash` = _hash;
#     END IF;

    SELECT _result AS `result`, _id AS `id`, _login AS `login`, _role AS `role`;
  END;
