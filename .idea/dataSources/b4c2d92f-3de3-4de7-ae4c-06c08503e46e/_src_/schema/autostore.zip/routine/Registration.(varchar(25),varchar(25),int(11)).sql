CREATE PROCEDURE Registration(IN `_login` VARCHAR(25), IN `_password` VARCHAR(25), IN `_roleId` INT)
  BEGIN
    DECLARE _result TINYINT DEFAULT IF(EXISTS(SELECT '' FROM `User` WHERE `login` = _login LIMIT 1), 1, 0);
    IF _result = 0 THEN
      INSERT INTO `User`(`login`,`hash`,`roleId`) VALUES (_login,SHA1(CONCAT(_login,'|', _password)),_roleId);
    END IF;
    SELECT _result AS result;
  END;
