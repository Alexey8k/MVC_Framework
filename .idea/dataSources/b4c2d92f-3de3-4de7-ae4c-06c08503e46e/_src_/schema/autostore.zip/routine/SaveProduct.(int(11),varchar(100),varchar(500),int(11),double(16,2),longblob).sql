CREATE PROCEDURE SaveProduct(IN `_id`         INT, IN `_name` VARCHAR(100), IN `_description` VARCHAR(500),
                             IN `_categoryId` INT, IN `_price` DOUBLE(16, 2), IN `_image` LONGBLOB)
  BEGIN
     IF IsExistsProduct(_id)
     THEN
       UPDATE `Product`
         SET `name`=_name,
           `description`=_description,
           `categoryId`=_categoryId,
           `price`=_price,
           `imageData`=TO_BASE64(_image)
       WHERE `id`=_id;
     ELSE
       INSERT INTO `Product`(`name`,`description`,`categoryId`,`price`,`imageData`)
         VALUES (_name,_description,_categoryId,_price,TO_BASE64(_image));
     END IF;
  END;
