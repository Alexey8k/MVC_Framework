CREATE PROCEDURE GetProduct(IN `_id` INT)
  BEGIN
    SELECT p.`id`,p.`name`,p.`price`,p.`description`,c.name category
    FROM `Product` p
      JOIN `Category` c ON p.categoryId = c.id
    WHERE p.`id`=_id
    LIMIT 1;
  END;
