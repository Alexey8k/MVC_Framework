CREATE PROCEDURE GetProductsByCategory(IN `_category` VARCHAR(25))
  BEGIN
    SELECT p.id,p.name,p.price,p.description,c.name category
    FROM `Product` p
      JOIN `Category` c ON p.categoryId = c.id
    WHERE p.categoryId IN (SELECT c.`id` FROM `Category` c WHERE c.`name`=_category OR _category='')
    ORDER BY `id`;
  END;
