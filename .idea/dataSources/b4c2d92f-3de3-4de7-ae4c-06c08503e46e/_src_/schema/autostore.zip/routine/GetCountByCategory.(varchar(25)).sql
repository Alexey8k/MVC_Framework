CREATE FUNCTION GetCountByCategory(`_category` VARCHAR(25))
  RETURNS INT
  BEGIN
    DECLARE `_conutByCategory` INT;
    SELECT COUNT(*) INTO `_conutByCategory`
    FROM `Product`
    WHERE categoryId IN (SELECT c.id FROM Category c WHERE c.name=_category OR _category='');
    RETURN `_conutByCategory`;
  END;
