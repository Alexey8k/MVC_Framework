CREATE PROCEDURE AddProductToOrder(IN `_orderId` INT, IN `_productId` INT, IN `_quantity` INT)
  BEGIN
    INSERT INTO `OrderProduct`(`orderId`,`productId`,`quantity`)
      VALUES (_orderId,_productId,_quantity);
  END;
