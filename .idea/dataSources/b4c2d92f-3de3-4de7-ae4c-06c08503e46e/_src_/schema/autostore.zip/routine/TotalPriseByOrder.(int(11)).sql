CREATE FUNCTION TotalPriseByOrder(`_id` INT)
  RETURNS DOUBLE
  BEGIN
    DECLARE _result DOUBLE(16,2);
    SELECT SUM(p.`price`*op.`quantity`) INTO _result
      FROM `OrderProduct` op
        JOIN `Product` p ON op.`productId` = p.`id`
      WHERE op.`orderId`=_id;
    RETURN _result;
  END;
