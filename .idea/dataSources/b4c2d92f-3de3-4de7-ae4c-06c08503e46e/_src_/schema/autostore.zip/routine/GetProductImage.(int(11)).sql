CREATE PROCEDURE GetProductImage(IN `_id` INT)
  BEGIN
    SELECT FROM_BASE64(`imageData`) as imageData FROM `Product` WHERE `id`=_id;
  END;
