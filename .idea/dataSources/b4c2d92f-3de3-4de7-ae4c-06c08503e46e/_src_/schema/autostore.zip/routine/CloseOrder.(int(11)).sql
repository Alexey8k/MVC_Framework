CREATE PROCEDURE CloseOrder(IN `_id` INT)
  BEGIN
    DECLARE _statusId INT;
    SELECT `id` INTO _statusId FROM `Status` WHERE `name`='close';
    UPDATE `Order`
      SET `statusId`=_statusId
    WHERE `id`=_id;
  END;
