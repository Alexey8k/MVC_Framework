CREATE PROCEDURE IsExistsLogin(IN `_login` VARCHAR(25))
  BEGIN
    SELECT IF((EXISTS(SELECT '' FROM User WHERE `login` = _login LIMIT 1)), TRUE, FALSE) AS result;
  END;
