CREATE PROCEDURE DeleteProduct(IN `_id` INT)
  BEGIN
    DELETE FROM `Product`
      WHERE `id`=_id;
  END;
