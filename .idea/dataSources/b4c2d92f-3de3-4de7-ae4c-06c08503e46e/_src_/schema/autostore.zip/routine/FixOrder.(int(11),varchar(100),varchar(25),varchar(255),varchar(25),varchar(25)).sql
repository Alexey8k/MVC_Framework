CREATE FUNCTION FixOrder(`_userId` INT, `_name` VARCHAR(100), `_phone` VARCHAR(25), `_address` VARCHAR(255),
                         `_city`   VARCHAR(25), `_country` VARCHAR(25))
  RETURNS INT
  BEGIN
    INSERT INTO `Order` (`userId`,`name`,`phone`,`address`,`city`,`country`)
      VALUES (_userId,_name,_phone,_address,_city,_country);
    RETURN last_insert_id();
  END;
