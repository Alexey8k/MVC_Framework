CREATE PROCEDURE GetOrder(IN `_id` INT)
  BEGIN
    SELECT o.id,s.name status,o.userId,o.name userName,o.date,o.phone,o.address,o.city,o.country
    FROM `Order` o
      JOIN `Status` s ON o.statusId = s.id
    WHERE o.id=_id
    LIMIT 1;

    CALL GetProductsByOrder(_id);
  END;
